window.addEventListener('load', function() {

	// usability enhancement: focus the delete button
	document.getElementById('btn-delete').focus();

});

// EOF
